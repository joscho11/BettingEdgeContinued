"""DraftKings NFL Classic skill-player scoring from an nflverse box score.

This is the training target. It is not a conversion off half-PPR.
DST is not scored here. The lineup optimizer uses DraftKings' season
average for the defense slot until a DST model exists.

Official Classic skill scoring:
- Pass: 0.04 per yard, 4 per TD, -1 per INT, +3 at 300 yards
- Rush: 0.1 per yard, 6 per TD, +3 at 100 yards
- Rec: 1 per catch, 0.1 per yard, 6 per TD, +3 at 100 yards
- 2-pt conversion: 2
- Fumble lost: -1
- Special-teams or fumble-recovery TD: 6
"""
from __future__ import annotations

import math

import pandas as pd

PASS_YD = 0.04
PASS_TD = 4.0
INT = -1.0
RUSH_YD = 0.1
REC_YD = 0.1
RECEPTION = 1.0
SKILL_TD = 6.0
TWO_PT = 2.0
FUMBLE_LOST = -1.0
BONUS = 3.0
PASS_BONUS_YD = 300.0
RUSH_BONUS_YD = 100.0
REC_BONUS_YD = 100.0

BOX_COLS = (
    "passing_yards",
    "passing_tds",
    "passing_interceptions",
    "rushing_yards",
    "rushing_tds",
    "receptions",
    "receiving_yards",
    "receiving_tds",
    "passing_2pt_conversions",
    "rushing_2pt_conversions",
    "receiving_2pt_conversions",
    "sack_fumbles_lost",
    "rushing_fumbles_lost",
    "receiving_fumbles_lost",
    "special_teams_tds",
    "fumble_recovery_tds",
)


def _col(df: pd.DataFrame, name: str) -> pd.Series:
    if name not in df.columns:
        return pd.Series(0.0, index=df.index)
    return pd.to_numeric(df[name], errors="coerce").fillna(0.0)


def dk_classic_points(df: pd.DataFrame) -> pd.Series:
    """Vectorized Classic points for skill-player rows."""
    pass_yd = _col(df, "passing_yards")
    rush_yd = _col(df, "rushing_yards")
    rec_yd = _col(df, "receiving_yards")
    pts = (
        PASS_YD * pass_yd
        + PASS_TD * _col(df, "passing_tds")
        + INT * _col(df, "passing_interceptions")
        + RUSH_YD * rush_yd
        + SKILL_TD * _col(df, "rushing_tds")
        + RECEPTION * _col(df, "receptions")
        + REC_YD * rec_yd
        + SKILL_TD * _col(df, "receiving_tds")
        + TWO_PT * (
            _col(df, "passing_2pt_conversions")
            + _col(df, "rushing_2pt_conversions")
            + _col(df, "receiving_2pt_conversions")
        )
        + FUMBLE_LOST * (
            _col(df, "sack_fumbles_lost")
            + _col(df, "rushing_fumbles_lost")
            + _col(df, "receiving_fumbles_lost")
        )
        + SKILL_TD * (_col(df, "special_teams_tds") + _col(df, "fumble_recovery_tds"))
        + BONUS * (pass_yd >= PASS_BONUS_YD).astype(float)
        + BONUS * (rush_yd >= RUSH_BONUS_YD).astype(float)
        + BONUS * (rec_yd >= REC_BONUS_YD).astype(float)
    )
    return pts.round(2)


def num(value, default: float = 0.0) -> float:
    if value is None:
        return default
    try:
        f = float(value)
    except (TypeError, ValueError):
        return default
    return default if math.isnan(f) or math.isinf(f) else f


def assert_objective_finite(players: pd.DataFrame, col: str = "proj_pts") -> None:
    s = pd.to_numeric(players[col], errors="coerce")
    bad = players[s.isna() | ~s.apply(lambda v: math.isfinite(v) if pd.notna(v) else False)]
    if len(bad):
        names = ", ".join(str(x) for x in bad.get("name", bad.index)[:10])
        raise ValueError(f"{len(bad)} row(s) have a non-finite {col}: {names}")
