"""Salaries plus direct DK-point projections into one Classic lineup."""
from __future__ import annotations

from io import StringIO
from pathlib import Path

import pandas as pd

from dst import apply_dst_projections, dst_caption
from matching import merge_projections
from optimizer import assign_slots, optimize_lineup
from salaries import load_dk_salaries, salary_eligibility, slate_summary
from scoring import assert_objective_finite

EXPORT_SLOTS = ("QB", "RB", "RB", "WR", "WR", "WR", "TE", "FLEX", "DST")
DIRECT_DK_UNITS = "direct_dk_points"
ENGINE_VERSION = "0.2.2"


def validate_projection_frame(proj: pd.DataFrame) -> tuple[int, int]:
    """Require one finite, explicitly direct-DK season/week artifact."""
    name_col = "player_display_name" if "player_display_name" in proj.columns else "player"
    required = {name_col, "position", "team", "season", "week", "projected_pts", "projection_units"}
    missing = sorted(required - set(proj.columns))
    if missing:
        raise KeyError(f"projection columns missing: {missing}")
    if proj.empty:
        raise ValueError("projection artifact is empty")
    units = set(proj["projection_units"].dropna().astype(str).str.strip())
    if units != {DIRECT_DK_UNITS} or proj["projection_units"].isna().any():
        raise ValueError(f"projection_units must be {DIRECT_DK_UNITS!r}, found {sorted(units)}")
    keys = proj[["season", "week"]].drop_duplicates()
    if len(keys) != 1:
        raise ValueError(f"projection artifact must contain one season/week, found {len(keys)}")
    season, week = (int(keys.iloc[0]["season"]), int(keys.iloc[0]["week"]))
    values = pd.to_numeric(proj["projected_pts"], errors="coerce")
    if values.isna().any() or (~values.map(lambda value: float("-inf") < value < float("inf"))).any():
        raise ValueError("projection artifact contains missing or non-finite projected_pts")
    invalid_positions = sorted(set(proj["position"].astype(str).str.upper()) - {"QB", "RB", "WR", "TE"})
    if invalid_positions:
        raise ValueError(f"projection artifact contains unsupported positions: {invalid_positions}")
    if "player_id" in proj.columns:
        ids = proj["player_id"]
        if ids.isna().any() or ids.astype(str).str.strip().eq("").any() or ids.astype(str).duplicated().any():
            raise ValueError("projection player_id values must be present and unique")
    return season, week


def validate_slate_alignment(dk: pd.DataFrame, projection_season: int) -> None:
    dates = pd.to_datetime(dk.get("slate_date", pd.Series(dtype=str)), format="%m/%d/%Y", errors="coerce")
    salary_seasons = {
        int(date.year - 1 if date.month <= 2 else date.year)
        for date in dates.dropna()
    }
    if not salary_seasons:
        raise ValueError("salary slate has no parsable Game Info date")
    if len(salary_seasons) != 1:
        raise ValueError(f"salary slate spans multiple NFL seasons: {sorted(salary_seasons)}")
    if salary_seasons != {int(projection_season)}:
        raise ValueError(
            f"salary slate season {sorted(salary_seasons)} does not match projection season {projection_season}"
        )


def build_pool_frames(dk: pd.DataFrame, proj: pd.DataFrame, *,
                      lines: pd.DataFrame | None = None) -> pd.DataFrame:
    """Build an auditable pool; only clean model matches and DST are solve-eligible."""
    projection_season, projection_week = validate_projection_frame(proj)
    validate_slate_alignment(dk, projection_season)
    dk = salary_eligibility(dk)
    name_col = "player_display_name" if "player_display_name" in proj.columns else "player"
    players = merge_projections(dk, proj, name_col=name_col)
    players = apply_dst_projections(
        players, proj=proj, lines=lines,
        season=projection_season, week=projection_week,
    )
    players["dfs_proj_pts"] = pd.to_numeric(players["proj_pts"], errors="coerce").fillna(0.0)
    assert_objective_finite(players, "dfs_proj_pts")
    match_ok = players["used_model"] | players["position"].eq("DST")
    players["optimization_eligible"] = players["salary_eligible"] & match_ok
    players["exclusion_reason"] = players["salary_exclusion_reason"].astype(str)
    missing_projection = players["salary_eligible"] & ~match_ok
    players.loc[missing_projection, "exclusion_reason"] = (
        "projection:" + players.loc[missing_projection, "match"].astype(str)
    )
    players.attrs.update({
        "projection_season": projection_season,
        "projection_week": projection_week,
        "projection_units": DIRECT_DK_UNITS,
        "dst_caption": dst_caption(players),
    })
    return players


def build_pool(salary_path, proj_path) -> pd.DataFrame:
    dk = load_dk_salaries(salary_path)
    proj = pd.read_csv(proj_path)
    return build_pool_frames(dk, proj)


def solve_pool(pool: pd.DataFrame, locked=None, excluded=None) -> pd.DataFrame | None:
    """Optimize an already-audited pool using stable DraftKings player keys."""
    eligible = pool[pool["optimization_eligible"]].copy()
    return optimize_lineup(
        eligible,
        locked=locked,
        excluded=excluded,
        objective_col="dfs_proj_pts",
        key_col="player_key",
    )


def solve(salary_path, proj_path, locked=None, excluded=None):
    pool = build_pool(salary_path, proj_path)
    lineup = solve_pool(pool, locked=locked, excluded=excluded)
    return pool, lineup, slate_summary(pool)


def lineup_to_dk_frame(lineup: pd.DataFrame) -> pd.DataFrame:
    """Return one DraftKings Classic upload row using the salary export identity token."""
    if "Slot" not in lineup.columns:
        lineup = assign_slots(lineup)
    by_slot: dict[str, list[str]] = {s: [] for s in ("QB", "RB", "WR", "TE", "FLEX", "DST")}
    for _, row in lineup.iterrows():
        token = str(row.get("name_id", "") or "").strip()
        if not token:
            dk_id = str(row.get("dk_id", "") or "").strip()
            if dk_id:
                token = f"{row['name']} ({dk_id})"
        if not token:
            raise ValueError(f"lineup row has no DraftKings Name + ID token: {row.get('name', '?')}")
        by_slot[str(row["Slot"])].append(token)
    ordered = []
    for slot in EXPORT_SLOTS:
        names = by_slot[slot]
        if not names:
            raise ValueError(f"lineup missing slot {slot}")
        ordered.append(names.pop(0))
    return pd.DataFrame([ordered], columns=list(EXPORT_SLOTS))


def lineup_csv_text(lineup: pd.DataFrame) -> str:
    buffer = StringIO()
    lineup_to_dk_frame(lineup).to_csv(buffer, index=False, lineterminator="\n")
    return buffer.getvalue()


def export_dk_csv(lineup: pd.DataFrame, path: str | Path) -> Path:
    """Write one row in DraftKings Classic upload column order."""
    dest = Path(path)
    out = lineup_to_dk_frame(lineup)
    dest.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(dest, index=False)
    return dest
