"""Classic DST projection from opponent implied total.

Locked 2026-08-24 by `notebooks/01_dst_points_backtest.ipynb` on 2021-2024
train / 2025 holdout. Not a player LightGBM. Ranking DST is fading a high
opponent implied score. The Normal bucket EV plus league-mean bonus puts
that rank on the Classic point scale so the ILP can trade DST vs skill.

If no game line is available, keep DraftKings' season average and label it.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from matching import norm_team

# 2021-2024 residual SD of (points allowed - implied opponent total).
PA_SIGMA = 9.113645497071793
# 2021-2024 mean of sack/INT/FR/safety/TD/block bonus.
LEAGUE_BONUS = 5.9434222631094755
PA_PTS = (10.0, 7.0, 4.0, 1.0, 0.0, -1.0, -4.0)


def _phi(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return 0.5 * (1.0 + np.vectorize(math.erf)(x / math.sqrt(2.0)))


def e_pa_points(mu, sigma: float = PA_SIGMA) -> np.ndarray:
    """Expected Classic points-allowed buckets if opponent score ~ N(mu, sigma)."""
    mu = np.asarray(mu, dtype=float)
    sig = float(sigma)
    bounds = np.array([-0.5, 6.5, 13.5, 20.5, 27.5, 34.5], dtype=float)
    cdf = [_phi((b - mu) / sig) for b in bounds]
    parts = [cdf[0]]
    for i in range(1, len(cdf)):
        parts.append(cdf[i] - cdf[i - 1])
    parts.append(1.0 - cdf[-1])
    return sum(weight * mass for weight, mass in zip(PA_PTS, parts))


def project_dst_points(implied_opp: float, *, sigma: float = PA_SIGMA,
                       bonus: float = LEAGUE_BONUS) -> float:
    return round(float(e_pa_points([implied_opp], sigma)[0] + bonus), 2)


def implied_opp_from_line(total_line: float, spread_line: float, *,
                          defense_is_home: bool) -> float:
    """Home-relative spread: positive means the home team is favored (D27)."""
    total = float(total_line)
    spread = float(spread_line)
    if defense_is_home:
        return total / 2.0 - spread / 2.0
    return total / 2.0 + spread / 2.0


def team_implied_map(proj: pd.DataFrame | None) -> dict[str, float]:
    if proj is None or "implied_team_total" not in proj.columns or "team" not in proj.columns:
        return {}
    tmp = proj.copy()
    tmp["_team"] = tmp["team"].map(norm_team)
    tmp["_imp"] = pd.to_numeric(tmp["implied_team_total"], errors="coerce")
    tmp = tmp.loc[tmp["_team"].ne("") & tmp["_imp"].notna()]
    if tmp.empty:
        return {}
    return {str(k): float(v) for k, v in tmp.groupby("_team")["_imp"].median().items()}


def load_schedule_lines(season: int | None, week: int | None = None) -> pd.DataFrame:
    empty = pd.DataFrame(columns=["home", "away", "spread_line", "total_line"])
    if season is None:
        return empty
    try:
        import paths
        sched = pd.read_parquet(paths.schedules_path())
    except (ImportError, FileNotFoundError, OSError):
        return empty
    out = sched.loc[sched.season.astype(int).eq(int(season))].copy()
    if week is not None and "week" in out.columns:
        out = out.loc[out.week.astype(int).eq(int(week))]
    need = {"home_team", "away_team", "spread_line", "total_line"}
    if out.empty or not need.issubset(out.columns):
        return empty
    out = out.loc[out.spread_line.notna() & out.total_line.notna()]
    return pd.DataFrame({
        "home": out.home_team.map(norm_team),
        "away": out.away_team.map(norm_team),
        "spread_line": pd.to_numeric(out.spread_line, errors="coerce"),
        "total_line": pd.to_numeric(out.total_line, errors="coerce"),
    }).dropna()


def _implied_opp_for_row(row, implied_map: dict[str, float],
                         lines: pd.DataFrame) -> float | None:
    team = norm_team(row.get("team"))
    home = norm_team(row.get("home"))
    away = norm_team(row.get("away"))
    if not team or not home or not away:
        return None
    if team == home:
        opp, defense_is_home = away, True
    elif team == away:
        opp, defense_is_home = home, False
    else:
        return None
    if opp in implied_map:
        return float(implied_map[opp])
    if lines is None or lines.empty:
        return None
    hit = lines.loc[lines.home.eq(home) & lines.away.eq(away)]
    if hit.empty:
        return None
    return implied_opp_from_line(
        float(hit.iloc[0]["total_line"]),
        float(hit.iloc[0]["spread_line"]),
        defense_is_home=defense_is_home,
    )


def apply_dst_projections(
    players: pd.DataFrame,
    *,
    proj: pd.DataFrame | None = None,
    lines: pd.DataFrame | None = None,
    season: int | None = None,
    week: int | None = None,
) -> pd.DataFrame:
    """Overwrite DST proj_pts when a line exists. Skill rows are untouched."""
    out = players.copy()
    if "dst_source" not in out.columns:
        out["dst_source"] = ""
    if "implied_opp" not in out.columns:
        out["implied_opp"] = np.nan
    dst = out["position"].astype(str).str.upper().eq("DST")
    out.loc[~dst, "dst_source"] = "not_dst"
    implied_map = team_implied_map(proj)
    line_table = lines if lines is not None else load_schedule_lines(season, week)
    for idx in out.index[dst]:
        mu = _implied_opp_for_row(out.loc[idx], implied_map, line_table)
        if mu is None:
            out.at[idx, "dst_source"] = "dk_average"
            out.at[idx, "match_note"] = "DST: DraftKings average (no game line)"
            continue
        out.at[idx, "implied_opp"] = mu
        out.at[idx, "proj_pts"] = project_dst_points(mu)
        out.at[idx, "dst_source"] = "vegas"
        out.at[idx, "match_note"] = f"DST: opponent implied {mu:.1f}"
    salary = pd.to_numeric(out.get("salary"), errors="coerce")
    pts = pd.to_numeric(out.get("proj_pts"), errors="coerce")
    out["value"] = (pts / (salary / 1000.0)).round(2)
    return out


def dst_caption(players: pd.DataFrame) -> str:
    dst = players[players["position"].astype(str).str.upper().eq("DST")]
    if dst.empty:
        return "No DST rows"
    n_vegas = int((dst.get("dst_source") == "vegas").sum())
    n_avg = int((dst.get("dst_source") == "dk_average").sum())
    if n_vegas and n_avg:
        return f"DST: {n_vegas} matchup projections, {n_avg} DraftKings averages"
    if n_vegas:
        return "DST: opponent implied total"
    return "DST: DraftKings average (no game line)"
